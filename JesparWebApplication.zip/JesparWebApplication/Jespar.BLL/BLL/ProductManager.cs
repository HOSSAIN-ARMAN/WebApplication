﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Jespar.Repository.Repository;
using Jespar.Model.Model;

namespace Jespar.BLL.BLL
{
    public class ProductManager
    {
        ProductRepository _productRepository = new ProductRepository();
        public bool Add(Product product)
        {
            return _productRepository.Add(product);
        }
        public List<Product> GetAll()
        {
            return _productRepository.GetAll();
        }
    }
}
